/*******************************************************************************
* File Name: AMux_calibrate.h
* Version 1.80
*
*  Description:
*    This file contains the constants and function prototypes for the AMuxSeq.
*
*   Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_AMUXSEQ_AMux_calibrate_H)
#define CY_AMUXSEQ_AMux_calibrate_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cyfitter_cfg.h"


/***************************************
*   Conditional Compilation Parameters
***************************************/

#define AMux_calibrate_MUX_SINGLE 1
#define AMux_calibrate_MUX_DIFF   2
#define AMux_calibrate_MUXTYPE    2


/***************************************
*        Function Prototypes
***************************************/

void AMux_calibrate_Start(void);
void AMux_calibrate_Init(void);
void AMux_calibrate_Stop(void);
#if (AMux_calibrate_MUXTYPE == AMux_calibrate_MUX_DIFF)
void AMux_calibrate_Next(void);
void AMux_calibrate_DisconnectAll(void);
#else
/* The Next and DisconnectAll functions are declared in cyfitter_cfg.h. */
/* void AMux_calibrate_Next(void); */
/* void AMux_calibrate_DisconnectAll(void); */
#endif
int8 AMux_calibrate_GetChannel(void);


/***************************************
*           Global Variables
***************************************/

extern uint8 AMux_calibrate_initVar;


/***************************************
*         Parameter Constants
***************************************/
#define AMux_calibrate_CHANNELS 1


#endif /* CY_AMUXSEQ_AMux_calibrate_H */


/* [] END OF FILE */
