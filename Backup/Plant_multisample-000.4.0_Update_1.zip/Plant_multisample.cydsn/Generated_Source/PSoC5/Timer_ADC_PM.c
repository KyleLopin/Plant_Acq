/*******************************************************************************
* File Name: Timer_ADC_PM.c
* Version 3.30
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Timer_ADC.h"

static Timer_ADC_backupStruct Timer_ADC_backup;


/*******************************************************************************
* Function Name: Timer_ADC_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  Timer_ADC_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void Timer_ADC_SaveConfig(void) 
{

    #if(!Timer_ADC_UsingFixedFunction)
        #if(!Timer_ADC_PWMModeIsCenterAligned)
            Timer_ADC_backup.PWMPeriod = Timer_ADC_ReadPeriod();
        #endif /* (!Timer_ADC_PWMModeIsCenterAligned) */
        Timer_ADC_backup.PWMUdb = Timer_ADC_ReadCounter();
        #if (Timer_ADC_UseStatus)
            Timer_ADC_backup.InterruptMaskValue = Timer_ADC_STATUS_MASK;
        #endif /* (Timer_ADC_UseStatus) */

        #if(Timer_ADC_DeadBandMode == Timer_ADC__B_PWM__DBM_256_CLOCKS || \
            Timer_ADC_DeadBandMode == Timer_ADC__B_PWM__DBM_2_4_CLOCKS)
            Timer_ADC_backup.PWMdeadBandValue = Timer_ADC_ReadDeadTime();
        #endif /*  deadband count is either 2-4 clocks or 256 clocks */

        #if(Timer_ADC_KillModeMinTime)
             Timer_ADC_backup.PWMKillCounterPeriod = Timer_ADC_ReadKillTime();
        #endif /* (Timer_ADC_KillModeMinTime) */

        #if(Timer_ADC_UseControl)
            Timer_ADC_backup.PWMControlRegister = Timer_ADC_ReadControlRegister();
        #endif /* (Timer_ADC_UseControl) */
    #endif  /* (!Timer_ADC_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Timer_ADC_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  Timer_ADC_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_ADC_RestoreConfig(void) 
{
        #if(!Timer_ADC_UsingFixedFunction)
            #if(!Timer_ADC_PWMModeIsCenterAligned)
                Timer_ADC_WritePeriod(Timer_ADC_backup.PWMPeriod);
            #endif /* (!Timer_ADC_PWMModeIsCenterAligned) */

            Timer_ADC_WriteCounter(Timer_ADC_backup.PWMUdb);

            #if (Timer_ADC_UseStatus)
                Timer_ADC_STATUS_MASK = Timer_ADC_backup.InterruptMaskValue;
            #endif /* (Timer_ADC_UseStatus) */

            #if(Timer_ADC_DeadBandMode == Timer_ADC__B_PWM__DBM_256_CLOCKS || \
                Timer_ADC_DeadBandMode == Timer_ADC__B_PWM__DBM_2_4_CLOCKS)
                Timer_ADC_WriteDeadTime(Timer_ADC_backup.PWMdeadBandValue);
            #endif /* deadband count is either 2-4 clocks or 256 clocks */

            #if(Timer_ADC_KillModeMinTime)
                Timer_ADC_WriteKillTime(Timer_ADC_backup.PWMKillCounterPeriod);
            #endif /* (Timer_ADC_KillModeMinTime) */

            #if(Timer_ADC_UseControl)
                Timer_ADC_WriteControlRegister(Timer_ADC_backup.PWMControlRegister);
            #endif /* (Timer_ADC_UseControl) */
        #endif  /* (!Timer_ADC_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: Timer_ADC_Sleep
********************************************************************************
*
* Summary:
*  Disables block's operation and saves the user configuration. Should be called
*  just prior to entering sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  Timer_ADC_backup.PWMEnableState:  Is modified depending on the enable
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void Timer_ADC_Sleep(void) 
{
    #if(Timer_ADC_UseControl)
        if(Timer_ADC_CTRL_ENABLE == (Timer_ADC_CONTROL & Timer_ADC_CTRL_ENABLE))
        {
            /*Component is enabled */
            Timer_ADC_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            Timer_ADC_backup.PWMEnableState = 0u;
        }
    #endif /* (Timer_ADC_UseControl) */

    /* Stop component */
    Timer_ADC_Stop();

    /* Save registers configuration */
    Timer_ADC_SaveConfig();
}


/*******************************************************************************
* Function Name: Timer_ADC_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration. Should be called just after
*  awaking from sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  Timer_ADC_backup.pwmEnable:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_ADC_Wakeup(void) 
{
     /* Restore registers values */
    Timer_ADC_RestoreConfig();

    if(Timer_ADC_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        Timer_ADC_Enable();
    } /* Do nothing if component's block was disabled before */

}


/* [] END OF FILE */
