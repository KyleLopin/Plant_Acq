/*******************************************************************************
* File Name: VDAC_vrt_gnd.c  
* Version 1.90
*
* Description:
*  This file provides the source code to the API for the 8-bit Voltage DAC 
*  (VDAC8) User Module.
*
* Note:
*  Any unusual or non-standard behavior should be noted here. Other-
*  wise, this section should remain blank.
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "VDAC_vrt_gnd.h"

#if (CY_PSOC5A)
#include <CyLib.h>
#endif /* CY_PSOC5A */

uint8 VDAC_vrt_gnd_initVar = 0u;

#if (CY_PSOC5A)
    static uint8 VDAC_vrt_gnd_restoreVal = 0u;
#endif /* CY_PSOC5A */

#if (CY_PSOC5A)
    static VDAC_vrt_gnd_backupStruct VDAC_vrt_gnd_backup;
#endif /* CY_PSOC5A */


/*******************************************************************************
* Function Name: VDAC_vrt_gnd_Init
********************************************************************************
* Summary:
*  Initialize to the schematic state.
* 
* Parameters:
*  void:
*
* Return:
*  void
*
* Theory:
*
* Side Effects:
*
*******************************************************************************/
void VDAC_vrt_gnd_Init(void) 
{
    VDAC_vrt_gnd_CR0 = (VDAC_vrt_gnd_MODE_V );

    /* Set default data source */
    #if(VDAC_vrt_gnd_DEFAULT_DATA_SRC != 0 )
        VDAC_vrt_gnd_CR1 = (VDAC_vrt_gnd_DEFAULT_CNTL | VDAC_vrt_gnd_DACBUS_ENABLE) ;
    #else
        VDAC_vrt_gnd_CR1 = (VDAC_vrt_gnd_DEFAULT_CNTL | VDAC_vrt_gnd_DACBUS_DISABLE) ;
    #endif /* (VDAC_vrt_gnd_DEFAULT_DATA_SRC != 0 ) */

    /* Set default strobe mode */
    #if(VDAC_vrt_gnd_DEFAULT_STRB != 0)
        VDAC_vrt_gnd_Strobe |= VDAC_vrt_gnd_STRB_EN ;
    #endif/* (VDAC_vrt_gnd_DEFAULT_STRB != 0) */

    /* Set default range */
    VDAC_vrt_gnd_SetRange(VDAC_vrt_gnd_DEFAULT_RANGE); 

    /* Set default speed */
    VDAC_vrt_gnd_SetSpeed(VDAC_vrt_gnd_DEFAULT_SPEED);
}


/*******************************************************************************
* Function Name: VDAC_vrt_gnd_Enable
********************************************************************************
* Summary:
*  Enable the VDAC8
* 
* Parameters:
*  void
*
* Return:
*  void
*
* Theory:
*
* Side Effects:
*
*******************************************************************************/
void VDAC_vrt_gnd_Enable(void) 
{
    VDAC_vrt_gnd_PWRMGR |= VDAC_vrt_gnd_ACT_PWR_EN;
    VDAC_vrt_gnd_STBY_PWRMGR |= VDAC_vrt_gnd_STBY_PWR_EN;

    /*This is to restore the value of register CR0 ,
    which is modified  in Stop API , this prevents misbehaviour of VDAC */
    #if (CY_PSOC5A)
        if(VDAC_vrt_gnd_restoreVal == 1u) 
        {
             VDAC_vrt_gnd_CR0 = VDAC_vrt_gnd_backup.data_value;
             VDAC_vrt_gnd_restoreVal = 0u;
        }
    #endif /* CY_PSOC5A */
}


/*******************************************************************************
* Function Name: VDAC_vrt_gnd_Start
********************************************************************************
*
* Summary:
*  The start function initializes the voltage DAC with the default values, 
*  and sets the power to the given level.  A power level of 0, is the same as
*  executing the stop function.
*
* Parameters:
*  Power: Sets power level between off (0) and (3) high power
*
* Return:
*  void 
*
* Global variables:
*  VDAC_vrt_gnd_initVar: Is modified when this function is called for the 
*  first time. Is used to ensure that initialization happens only once.
*
*******************************************************************************/
void VDAC_vrt_gnd_Start(void)  
{
    /* Hardware initiazation only needs to occure the first time */
    if(VDAC_vrt_gnd_initVar == 0u)
    { 
        VDAC_vrt_gnd_Init();
        VDAC_vrt_gnd_initVar = 1u;
    }

    /* Enable power to DAC */
    VDAC_vrt_gnd_Enable();

    /* Set default value */
    VDAC_vrt_gnd_SetValue(VDAC_vrt_gnd_DEFAULT_DATA); 
}


/*******************************************************************************
* Function Name: VDAC_vrt_gnd_Stop
********************************************************************************
*
* Summary:
*  Powers down DAC to lowest power state.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Theory:
*
* Side Effects:
*
*******************************************************************************/
void VDAC_vrt_gnd_Stop(void) 
{
    /* Disble power to DAC */
    VDAC_vrt_gnd_PWRMGR &= (uint8)(~VDAC_vrt_gnd_ACT_PWR_EN);
    VDAC_vrt_gnd_STBY_PWRMGR &= (uint8)(~VDAC_vrt_gnd_STBY_PWR_EN);

    /* This is a work around for PSoC5A  ,
    this sets VDAC to current mode with output off */
    #if (CY_PSOC5A)
        VDAC_vrt_gnd_backup.data_value = VDAC_vrt_gnd_CR0;
        VDAC_vrt_gnd_CR0 = VDAC_vrt_gnd_CUR_MODE_OUT_OFF;
        VDAC_vrt_gnd_restoreVal = 1u;
    #endif /* CY_PSOC5A */
}


/*******************************************************************************
* Function Name: VDAC_vrt_gnd_SetSpeed
********************************************************************************
*
* Summary:
*  Set DAC speed
*
* Parameters:
*  power: Sets speed value
*
* Return:
*  void
*
* Theory:
*
* Side Effects:
*
*******************************************************************************/
void VDAC_vrt_gnd_SetSpeed(uint8 speed) 
{
    /* Clear power mask then write in new value */
    VDAC_vrt_gnd_CR0 &= (uint8)(~VDAC_vrt_gnd_HS_MASK);
    VDAC_vrt_gnd_CR0 |=  (speed & VDAC_vrt_gnd_HS_MASK);
}


/*******************************************************************************
* Function Name: VDAC_vrt_gnd_SetRange
********************************************************************************
*
* Summary:
*  Set one of three current ranges.
*
* Parameters:
*  Range: Sets one of Three valid ranges.
*
* Return:
*  void 
*
* Theory:
*
* Side Effects:
*
*******************************************************************************/
void VDAC_vrt_gnd_SetRange(uint8 range) 
{
    VDAC_vrt_gnd_CR0 &= (uint8)(~VDAC_vrt_gnd_RANGE_MASK);      /* Clear existing mode */
    VDAC_vrt_gnd_CR0 |= (range & VDAC_vrt_gnd_RANGE_MASK);      /*  Set Range  */
    VDAC_vrt_gnd_DacTrim();
}


/*******************************************************************************
* Function Name: VDAC_vrt_gnd_SetValue
********************************************************************************
*
* Summary:
*  Set 8-bit DAC value
*
* Parameters:  
*  value:  Sets DAC value between 0 and 255.
*
* Return: 
*  void 
*
* Theory: 
*
* Side Effects:
*
*******************************************************************************/
void VDAC_vrt_gnd_SetValue(uint8 value) 
{
    #if (CY_PSOC5A)
        uint8 VDAC_vrt_gnd_intrStatus = CyEnterCriticalSection();
    #endif /* CY_PSOC5A */

    VDAC_vrt_gnd_Data = value;                /*  Set Value  */

    /* PSOC5A requires a double write */
    /* Exit Critical Section */
    #if (CY_PSOC5A)
        VDAC_vrt_gnd_Data = value;
        CyExitCriticalSection(VDAC_vrt_gnd_intrStatus);
    #endif /* CY_PSOC5A */
}


/*******************************************************************************
* Function Name: VDAC_vrt_gnd_DacTrim
********************************************************************************
*
* Summary:
*  Set the trim value for the given range.
*
* Parameters:
*  range:  1V or 4V range.  See constants.
*
* Return:
*  void
*
* Theory: 
*
* Side Effects:
*
*******************************************************************************/
void VDAC_vrt_gnd_DacTrim(void) 
{
    uint8 mode;

    mode = (uint8)((VDAC_vrt_gnd_CR0 & VDAC_vrt_gnd_RANGE_MASK) >> 2) + VDAC_vrt_gnd_TRIM_M7_1V_RNG_OFFSET;
    VDAC_vrt_gnd_TR = CY_GET_XTND_REG8((uint8 *)(VDAC_vrt_gnd_DAC_TRIM_BASE + mode));
}


/* [] END OF FILE */
