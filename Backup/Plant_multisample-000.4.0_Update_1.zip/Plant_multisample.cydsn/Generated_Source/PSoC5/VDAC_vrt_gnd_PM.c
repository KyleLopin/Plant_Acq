/*******************************************************************************
* File Name: VDAC_vrt_gnd_PM.c  
* Version 1.90
*
* Description:
*  This file provides the power management source code to API for the
*  VDAC8.  
*
* Note:
*  None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "VDAC_vrt_gnd.h"

static VDAC_vrt_gnd_backupStruct VDAC_vrt_gnd_backup;


/*******************************************************************************
* Function Name: VDAC_vrt_gnd_SaveConfig
********************************************************************************
* Summary:
*  Save the current user configuration
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
*******************************************************************************/
void VDAC_vrt_gnd_SaveConfig(void) 
{
    if (!((VDAC_vrt_gnd_CR1 & VDAC_vrt_gnd_SRC_MASK) == VDAC_vrt_gnd_SRC_UDB))
    {
        VDAC_vrt_gnd_backup.data_value = VDAC_vrt_gnd_Data;
    }
}


/*******************************************************************************
* Function Name: VDAC_vrt_gnd_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
*******************************************************************************/
void VDAC_vrt_gnd_RestoreConfig(void) 
{
    if (!((VDAC_vrt_gnd_CR1 & VDAC_vrt_gnd_SRC_MASK) == VDAC_vrt_gnd_SRC_UDB))
    {
        if((VDAC_vrt_gnd_Strobe & VDAC_vrt_gnd_STRB_MASK) == VDAC_vrt_gnd_STRB_EN)
        {
            VDAC_vrt_gnd_Strobe &= (uint8)(~VDAC_vrt_gnd_STRB_MASK);
            VDAC_vrt_gnd_Data = VDAC_vrt_gnd_backup.data_value;
            VDAC_vrt_gnd_Strobe |= VDAC_vrt_gnd_STRB_EN;
        }
        else
        {
            VDAC_vrt_gnd_Data = VDAC_vrt_gnd_backup.data_value;
        }
    }
}


/*******************************************************************************
* Function Name: VDAC_vrt_gnd_Sleep
********************************************************************************
* Summary:
*  Stop and Save the user configuration
*
* Parameters:  
*  void:  
*
* Return: 
*  void
*
* Global variables:
*  VDAC_vrt_gnd_backup.enableState:  Is modified depending on the enable 
*  state  of the block before entering sleep mode.
*
*******************************************************************************/
void VDAC_vrt_gnd_Sleep(void) 
{
    /* Save VDAC8's enable state */    
    if(VDAC_vrt_gnd_ACT_PWR_EN == (VDAC_vrt_gnd_PWRMGR & VDAC_vrt_gnd_ACT_PWR_EN))
    {
        /* VDAC8 is enabled */
        VDAC_vrt_gnd_backup.enableState = 1u;
    }
    else
    {
        /* VDAC8 is disabled */
        VDAC_vrt_gnd_backup.enableState = 0u;
    }
    
    VDAC_vrt_gnd_Stop();
    VDAC_vrt_gnd_SaveConfig();
}


/*******************************************************************************
* Function Name: VDAC_vrt_gnd_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  VDAC_vrt_gnd_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void VDAC_vrt_gnd_Wakeup(void) 
{
    VDAC_vrt_gnd_RestoreConfig();
    
    if(VDAC_vrt_gnd_backup.enableState == 1u)
    {
        /* Enable VDAC8's operation */
        VDAC_vrt_gnd_Enable();

        /* Restore the data register */
        VDAC_vrt_gnd_SetValue(VDAC_vrt_gnd_Data);
    } /* Do nothing if VDAC8 was disabled before */    
}


/* [] END OF FILE */
